//
//  timerModel.swift
//  timerList-Daniel
//
//  Created by Daniel on 10/23/25.
//

import Foundation

struct timerModel: Identifiable {
    let id: UUID = UUID()
    var start: Date?
    var elapsed: TimeInterval = 0
    
    mutating func toggle() {
        if let start = start {
            elapsed += Date().timeIntervalSince(start)
            self.start = nil
        } else {
            start = Date()
        }
    }
    
    func currentElapsed() -> String {
        let total = elapsed + (start.map({ Date().timeIntervalSince($0) }) ?? 0)
        let s = Int(total) % 60
        return String(format: "%0d", s)
    }
}
