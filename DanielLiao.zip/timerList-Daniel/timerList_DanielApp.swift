//
//  timerList_DanielApp.swift
//  timerList-Daniel
//
//  Created by Daniel on 10/23/25.
//

import SwiftUI

@main
struct timerList_DanielApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
