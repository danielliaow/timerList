//
//  ContentView.swift
//  timerList-Daniel
//
//  Created by Daniel on 10/23/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var vm = timerViewModel()
    @State var timerID: UUID = UUID()
    var body: some View {
        VStack {
            List {
                ForEach(vm.timers) { timer in
                    HStack {
                        Text(timer.currentElapsed())
                        Button(timer.start == nil ? "start" : "pause") {
                            vm.toggle(timer.id)
                            timerID = timer.id
                        }
                    }
                    .onAppear {
                        vm.toggle(timerID)
                    }
                }
                
                
            }
        }
        .padding()
    }
}
