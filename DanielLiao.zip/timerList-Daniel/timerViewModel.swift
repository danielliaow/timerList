//
//  timerViewModel.swift
//  timerList-Daniel
//
//  Created by Daniel on 10/23/25.
//

import Foundation

@MainActor
class timerViewModel: ObservableObject {
    @Published var timers: [timerModel] = []
    
    init() {
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
            self.objectWillChange.send()
        }
        add50Timers()
    }
    
    func toggle(_ id:UUID) {
        guard let index = timers.firstIndex(where: { $0.id == id }) else { return }
        timers[index].toggle()
    }
    
    func add50Timers() {
        for _ in 0..<50 {
            timers.append(timerModel())
        }
    }
    
}
